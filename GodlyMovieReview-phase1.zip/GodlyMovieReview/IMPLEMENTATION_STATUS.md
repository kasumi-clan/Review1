# IMPLEMENTATION_STATUS — GODLY AI MOVIE REVIEW

Cập nhật: Giai đoạn 1. Đọc tệp này trước khi tiếp tục làm.

## Trạng thái từng mục

| Mục | Đã viết code | Đã build | Đã kiểm thử | Ghi chú |
|---|---|---|---|---|
| Khung Gradle/Compose/Navigation | Có | **Chưa** | Chưa | chưa chạy Gradle lần nào |
| Home, Nhập video, Cài đặt | Có | Chưa | Chưa | cần chạy thử trên máy thật |
| Đọc thông tin video (MediaMetadataRetriever/MediaExtractor) | Có | Chưa | Chưa | FPS có thể "Không xác định" tùy tệp |
| Room (models, projects) | Có | Chưa | Chưa | |
| Model Manager (tải/tiếp tục/kiểm tra/cập nhật/xóa) | Có | Chưa | Unit test viết sẵn, **chưa chạy** | tải chạy trong tiến trình app, chưa có foreground service |
| Unit test (Formatters, Manifest, Validator, Downloader cục bộ Range) | Có | Chưa | **Chưa chạy** | cần Gradle |
| `scripts/verify_project.py` | Có | — | **Đã chạy** (sandbox) | |
| `scripts/verify_models.py` | Có | — | Logic parse đã chạy với máy chủ cục bộ; **chưa chạy với Internet thật** | |
| GitHub Actions `build-apk.yml` | Có | **Chưa chạy** | Chưa | |

## Chưa hoàn thành

- Giai đoạn 2: tích hợp llama.cpp và whisper.cpp (NDK/CMake/JNI), nạp model thật, test arm64. Workflow cần thêm NDK + CMake.
- Giai đoạn 3–4: phân tích video/transcript, Story/Short generator, Script Validator (chống bịa nội dung), Script Editor.
- Giai đoạn 5: Vietsub (ML Kit), TTS tiếng Việt (chưa chọn model/giấy phép; dự phòng Android TextToSpeech), Subtitle Editor.
- Giai đoạn 6: Video Renderer (MediaCodec/MediaMuxer), Audio Mixer, Export.
- Màn hình: Review Settings, AI Processing, Script Editor, Subtitle Editor, Export.
- DataStore, WorkManager, tạm dừng khi máy nóng, giới hạn RAM, tiếp tục công việc sau khi đóng app (sẽ thêm khi có tính năng dùng đến).
- Release APK có ký (build.gradle.kts đã đọc keystore từ biến môi trường, chưa có bước workflow).
- Gradle Wrapper (không tạo được khi không có Internet), tệp LICENSE (chờ chủ dự án chọn).

## Điều chưa xác minh (rủi ro đã biết)

- Chưa biết bản dựng đầu tiên có biên dịch sạch không; phiên bản thư viện (AGP 8.5.2, Kotlin 2.0.20, KSP 2.0.20-1.0.25, Compose BOM 2024.09.00, Room 2.6.1, Navigation 2.8.0) chọn theo hiểu biết, chưa kiểm tra online.
- URL/giấy phép/kích thước model trong manifest chưa xác minh; `sha256` là null.
- Magic 4 byte của tệp whisper ggml (`lmgg`) lấy theo đặc tả, chưa kiểm tra với tệp thật; nếu sai, model hợp lệ sẽ bị báo "Không tương thích".
- Tải model chưa chạy qua foreground service nên có thể bị hệ thống dừng khi app ở nền lâu; có thể bấm "Tiếp tục tải".

## Giới hạn phần cứng cần nhớ (Galaxy A51)

CPU-only, RAM 5–6 GB: không chạy nhiều model lớn cùng lúc; xử lý video theo đoạn; giải phóng RAM sau mỗi tác vụ.

## Việc tiếp theo

1. Đẩy lên GitHub, chạy workflow, sửa mọi lỗi biên dịch/test từ log thật.
2. Chạy `verify_models.py --write` khi có Internet.
3. Chỉ khi bản này build xanh mới bắt đầu Giai đoạn 2.
