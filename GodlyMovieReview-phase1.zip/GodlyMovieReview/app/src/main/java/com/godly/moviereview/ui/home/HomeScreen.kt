package com.godly.moviereview.ui.home

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.godly.moviereview.container
import com.godly.moviereview.model.ModelItem
import com.godly.moviereview.model.ModelState
import com.godly.moviereview.storage.NetworkStatus
import com.godly.moviereview.storage.ProjectEntity
import com.godly.moviereview.ui.components.GhostButton
import com.godly.moviereview.ui.components.GlowCard
import com.godly.moviereview.ui.components.InfoRow
import com.godly.moviereview.ui.components.LogoHeader
import com.godly.moviereview.ui.components.PrimaryButton
import com.godly.moviereview.ui.components.StatusChip
import com.godly.moviereview.ui.theme.GodlyBg
import com.godly.moviereview.ui.theme.GodlyBlueLight
import com.godly.moviereview.ui.theme.GodlyDanger
import com.godly.moviereview.ui.theme.GodlyOk
import com.godly.moviereview.ui.theme.GodlyText
import com.godly.moviereview.ui.theme.GodlyTextDim
import com.godly.moviereview.ui.theme.GodlyWarn
import com.godly.moviereview.util.formatBytes
import com.godly.moviereview.util.formatDuration
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    val recent: StateFlow<List<ProjectEntity>> = container().database.projectDao().observeRecent(10)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val models: StateFlow<List<ModelItem>> = container().models.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun deleteProject(id: Long) {
        viewModelScope.launch { container().database.projectDao().delete(id) }
    }
}

fun modelStateColor(state: ModelState) = when (state) {
    ModelState.DOWNLOADED -> GodlyOk
    ModelState.DOWNLOADING, ModelState.VERIFYING -> GodlyBlueLight
    ModelState.ERROR -> GodlyDanger
    ModelState.INCOMPATIBLE, ModelState.NOT_CONFIGURED -> GodlyWarn
    ModelState.NOT_DOWNLOADED -> GodlyTextDim
}

@Composable
fun HomeScreen(
    onNewProject: () -> Unit,
    onOpenModels: () -> Unit,
    onOpenSettings: () -> Unit,
    vm: HomeViewModel = viewModel()
) {
    val recent by vm.recent.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    val online = NetworkStatus.isOnline(LocalContext.current)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GodlyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { LogoHeader("AI MOVIE REVIEW") }

        item {
            GlowCard {
                Text("Dự án mới", color = GodlyText, fontSize = 18.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Chọn video bạn có quyền sử dụng. Ứng dụng chỉ đọc video gốc, không sao chép và không ghi đè.",
                    color = GodlyTextDim, fontSize = 13.sp
                )
                Spacer(Modifier.height(12.dp))
                PrimaryButton("Chọn video", Modifier.fillMaxWidth(), onClick = onNewProject)
            }
        }

        item {
            GlowCard {
                Text("Trạng thái model", color = GodlyText, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                if (models.isEmpty()) {
                    Text("Đang đọc danh sách model…", color = GodlyTextDim, fontSize = 13.sp)
                }
                models.forEach { m ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(m.spec.name, color = GodlyText, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        StatusChip(m.state.label, modelStateColor(m.state))
                    }
                }
                Spacer(Modifier.height(8.dp))
                GhostButton("Quản lý model", Modifier.fillMaxWidth(), onClick = onOpenModels)
            }
        }

        item {
            GlowCard {
                Text("Mạng và offline", color = GodlyText, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                InfoRow("Kết nối hiện tại", if (online) "Có Internet" else "Không có Internet")
                Text(
                    "Bản Giai đoạn 1 chưa có pipeline AI nên chưa thể tạo review, dù online hay offline. " +
                        "Hiện app mới nhập video, đọc thông tin video và quản lý model.",
                    color = GodlyTextDim, fontSize = 13.sp
                )
            }
        }

        item { Text("Video gần đây", color = GodlyText, fontSize = 18.sp) }

        if (recent.isEmpty()) {
            item { Text("Chưa có video nào được lưu.", color = GodlyTextDim, fontSize = 13.sp) }
        } else {
            items(recent, key = { it.id }) { p ->
                GlowCard {
                    Text(p.displayName, color = GodlyText, fontSize = 15.sp, maxLines = 2)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${p.width}×${p.height} · ${formatDuration(p.durationMs)} · ${formatBytes(p.sizeBytes)}",
                        color = GodlyTextDim, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    GhostButton("Xóa khỏi danh sách", color = GodlyDanger, onClick = { vm.deleteProject(p.id) })
                }
            }
        }

        item { GhostButton("Cài đặt", Modifier.fillMaxWidth(), onClick = onOpenSettings) }
    }
}
