package com.godly.moviereview.ui.importvideo

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.godly.moviereview.analyzer.VideoInfo
import com.godly.moviereview.analyzer.VideoInfoReader
import com.godly.moviereview.container
import com.godly.moviereview.storage.ProjectEntity
import com.godly.moviereview.ui.components.GhostButton
import com.godly.moviereview.ui.components.GlowCard
import com.godly.moviereview.ui.components.InfoRow
import com.godly.moviereview.ui.components.PrimaryButton
import com.godly.moviereview.ui.components.ScreenHeader
import com.godly.moviereview.ui.theme.GodlyBg
import com.godly.moviereview.ui.theme.GodlyDanger
import com.godly.moviereview.ui.theme.GodlyOk
import com.godly.moviereview.ui.theme.GodlyTextDim
import com.godly.moviereview.util.formatBytes
import com.godly.moviereview.util.formatDuration
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface ImportUiState {
    data object Idle : ImportUiState
    data object Loading : ImportUiState
    data class Loaded(val info: VideoInfo, val saved: Boolean = false) : ImportUiState
    data class Failed(val message: String) : ImportUiState
}

class ImportViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow<ImportUiState>(ImportUiState.Idle)
    val state: StateFlow<ImportUiState> = _state.asStateFlow()

    fun onPicked(uri: Uri) {
        _state.value = ImportUiState.Loading
        viewModelScope.launch {
            runCatching {
                getApplication<Application>().contentResolver
                    .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            VideoInfoReader.read(getApplication(), uri)
                .onSuccess { _state.value = ImportUiState.Loaded(it) }
                .onFailure { _state.value = ImportUiState.Failed(it.message ?: "Không đọc được video") }
        }
    }

    fun save() {
        val current = _state.value as? ImportUiState.Loaded ?: return
        viewModelScope.launch {
            val i = current.info
            container().database.projectDao().insert(
                ProjectEntity(
                    videoUri = i.uri.toString(),
                    displayName = i.displayName,
                    durationMs = i.durationMs,
                    width = i.width,
                    height = i.height,
                    fps = i.fps,
                    sizeBytes = i.sizeBytes,
                    createdAt = System.currentTimeMillis()
                )
            )
            _state.value = current.copy(saved = true)
        }
    }
}

@Composable
fun ImportScreen(onBack: () -> Unit, vm: ImportViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.onPicked(uri)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GodlyBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Nhập video", onBack)

        PrimaryButton(
            if (state is ImportUiState.Loaded) "Chọn video khác" else "Chọn video",
            Modifier.fillMaxWidth()
        ) { picker.launch(arrayOf("video/*")) }

        when (val s = state) {
            ImportUiState.Idle -> Text(
                "Hỗ trợ các định dạng mà bộ giải mã của máy đọc được (MP4, và MKV nếu máy hỗ trợ).",
                color = GodlyTextDim, fontSize = 13.sp
            )
            ImportUiState.Loading -> CircularProgressIndicator()
            is ImportUiState.Failed -> Text(s.message, color = GodlyDanger, fontSize = 14.sp)
            is ImportUiState.Loaded -> {
                VideoPreview(s.info.uri)
                GlowCard {
                    val i = s.info
                    InfoRow("Tên", i.displayName)
                    InfoRow("Dung lượng", formatBytes(i.sizeBytes))
                    InfoRow("Độ phân giải", "${i.width}×${i.height}")
                    InfoRow("FPS", i.fps?.let { String.format(Locale.US, "%.2f", it) } ?: "Không xác định")
                    InfoRow("Thời lượng", formatDuration(i.durationMs))
                    InfoRow("Định dạng", i.mime ?: "Không xác định")
                }
                if (s.saved) {
                    Text("Đã lưu vào danh sách video gần đây.", color = GodlyOk, fontSize = 14.sp)
                } else {
                    GhostButton("Lưu vào danh sách gần đây", Modifier.fillMaxWidth(), onClick = vm::save)
                }
                GlowCard {
                    Text(
                        "Các bước tiếp theo (nhận diện lời thoại, phân tích cảnh, viết kịch bản, giọng đọc, Vietsub, xuất MP4) " +
                            "chưa được triển khai ở Giai đoạn 1 nên chưa có nút chạy.",
                        color = GodlyTextDim, fontSize = 13.sp
                    )
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun VideoPreview(uri: Uri) {
    key(uri) {
        var view by remember { mutableStateOf<VideoView?>(null) }
        var playing by remember { mutableStateOf(false) }

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clip(RoundedCornerShape(16.dp)),
            factory = { ctx ->
                VideoView(ctx).also { v ->
                    v.setVideoURI(uri)
                    v.setOnPreparedListener { v.seekTo(1) }
                    v.setOnCompletionListener { playing = false }
                    view = v
                }
            }
        )
        GhostButton(if (playing) "Tạm dừng" else "Xem trước", Modifier.fillMaxWidth()) {
            val v = view ?: return@GhostButton
            if (v.isPlaying) {
                v.pause()
                playing = false
            } else {
                v.start()
                playing = true
            }
        }
        DisposableEffect(Unit) {
            onDispose { view?.stopPlayback() }
        }
    }
}
