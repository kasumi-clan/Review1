package com.godly.moviereview.analyzer

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoInfo(
    val uri: Uri,
    val displayName: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Float?,
    val mime: String?
)

/** Đọc thông tin thật của video bằng MediaMetadataRetriever / MediaExtractor. Không sao chép, không ghi đè tệp gốc. */
object VideoInfoReader {

    suspend fun read(context: Context, uri: Uri): Result<VideoInfo> = withContext(Dispatchers.IO) {
        runCatching {
            var name = "video"
            var size = -1L
            context.contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
            if (size < 0) {
                size = context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
            }

            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(context, uri)
                val duration = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                var w = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                var h = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rotation = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                require(w > 0 && h > 0) { "Tệp này không có luồng hình ảnh hoặc máy không đọc được" }
                if (rotation == 90 || rotation == 270) {
                    val t = w; w = h; h = t
                }
                val mime = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
                val capFps = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull()
                VideoInfo(
                    uri = uri,
                    displayName = name,
                    sizeBytes = size,
                    durationMs = duration,
                    width = w,
                    height = h,
                    fps = readFpsFromExtractor(context, uri) ?: capFps,
                    mime = mime
                )
            } finally {
                mmr.release()
            }
        }
    }

    private fun readFpsFromExtractor(context: Context, uri: Uri): Float? {
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(context, uri, null)
            var result: Float? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val isVideo = f.getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
                if (isVideo && f.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                    result = runCatching { f.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat() }
                        .recoverCatching { f.getFloat(MediaFormat.KEY_FRAME_RATE) }
                        .getOrNull()
                    break
                }
            }
            result
        } catch (e: Exception) {
            null
        } finally {
            extractor.release()
        }
    }
}
