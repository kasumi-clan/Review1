package com.godly.moviereview.model

import android.content.Context
import com.godly.moviereview.storage.ModelDao
import com.godly.moviereview.storage.ModelEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap

data class ModelItem(
    val spec: ModelSpec,
    val state: ModelState,
    val downloadedBytes: Long,
    val totalBytes: Long,
    val checksumVerified: Boolean,
    val installedVersion: String?,
    val errorMessage: String?
) {
    val updateAvailable: Boolean
        get() = state == ModelState.DOWNLOADED && installedVersion != null && installedVersion != spec.version
    val canResume: Boolean
        get() = state == ModelState.NOT_DOWNLOADED && downloadedBytes > 0
}

class ModelRepository(
    context: Context,
    private val dao: ModelDao,
    private val scope: CoroutineScope
) {
    private val appContext = context.applicationContext

    val specs: List<ModelSpec> = appContext.assets.open("model_manifest.json")
        .bufferedReader().use { ModelManifestParser.parse(it.readText()) }

    private val modelsDir = File(appContext.filesDir, "models")
    private val downloader = ModelDownloader(modelsDir)
    private val jobs = ConcurrentHashMap<String, Job>()

    fun observe(): Flow<List<ModelItem>> = dao.observeAll().map { rows ->
        val byId = rows.associateBy { it.id }
        specs.map { toItem(it, byId[it.id]) }
    }

    /** Fail-safe sau khi app bị đóng giữa chừng: đưa trạng thái về đúng với tệp thật trên đĩa. */
    suspend fun reconcile() = withContext(Dispatchers.IO) {
        for (spec in specs) {
            val name = spec.fileName ?: continue
            if (!spec.configured) continue
            val row = dao.get(spec.id)
            val target = downloader.targetFile(name)
            val part = downloader.partFile(name)
            val partBytes = if (part.exists()) part.length() else 0L
            when {
                row == null && partBytes > 0 ->
                    save(spec, ModelState.NOT_DOWNLOADED, partBytes, spec.sizeBytes ?: 0L, null, false, null)
                row == null -> Unit
                row.state == ModelState.DOWNLOADING.name ->
                    save(spec, ModelState.NOT_DOWNLOADED, partBytes, row.totalBytes, row.installedVersion, false, null)
                row.state == ModelState.VERIFYING.name ->
                    if (target.exists()) verifyInternal(spec)
                    else save(spec, ModelState.NOT_DOWNLOADED, partBytes, row.totalBytes, null, false, null)
                row.state == ModelState.DOWNLOADED.name && !target.exists() ->
                    save(spec, ModelState.NOT_DOWNLOADED, partBytes, row.totalBytes, null, false, null)
            }
        }
    }

    fun startDownload(id: String) {
        val spec = specs.firstOrNull { it.id == id } ?: return
        val name = spec.fileName ?: return
        val url = spec.url ?: return
        if (jobs[id]?.isActive == true) return

        jobs[id] = scope.launch {
            // Nếu còn tệp cũ (lỗi/không tương thích) thì xóa để tải lại sạch.
            downloader.targetFile(name).delete()
            val part = downloader.partFile(name)
            val prevTotal = dao.get(id)?.totalBytes ?: (spec.sizeBytes ?: 0L)
            save(spec, ModelState.DOWNLOADING, if (part.exists()) part.length() else 0L, prevTotal, null, false, null)
            try {
                downloader.download(url, name) { p ->
                    save(spec, ModelState.DOWNLOADING, p.downloaded, p.total.coerceAtLeast(0L), null, false, null)
                }
                verifyInternal(spec)
            } catch (e: CancellationException) {
                withContext(NonCancellable) {
                    val partBytes = if (part.exists()) part.length() else 0L
                    save(spec, ModelState.NOT_DOWNLOADED, partBytes, dao.get(id)?.totalBytes ?: 0L, null, false, null)
                }
                throw e
            } catch (e: Exception) {
                val partBytes = if (part.exists()) part.length() else 0L
                save(spec, ModelState.ERROR, partBytes, dao.get(id)?.totalBytes ?: 0L, null, false, e.message ?: "Lỗi tải model")
            }
        }
    }

    fun cancelDownload(id: String) {
        jobs[id]?.cancel()
    }

    fun verify(id: String) {
        val spec = specs.firstOrNull { it.id == id } ?: return
        if (!spec.configured || jobs[id]?.isActive == true) return
        jobs[id] = scope.launch { verifyInternal(spec) }
    }

    /** "Cập nhật" = tải lại bản theo version hiện tại trong manifest. */
    fun update(id: String) {
        val spec = specs.firstOrNull { it.id == id } ?: return
        val name = spec.fileName ?: return
        if (jobs[id]?.isActive == true) return
        downloader.targetFile(name).delete()
        downloader.partFile(name).delete()
        startDownload(id)
    }

    fun delete(id: String) {
        val spec = specs.firstOrNull { it.id == id } ?: return
        val name = spec.fileName ?: return
        scope.launch {
            jobs[id]?.cancelAndJoin()
            withContext(Dispatchers.IO) {
                downloader.targetFile(name).delete()
                downloader.partFile(name).delete()
            }
            dao.delete(id)
        }
    }

    private suspend fun verifyInternal(spec: ModelSpec) {
        val name = spec.fileName ?: return
        val file = downloader.targetFile(name)
        val row = dao.get(spec.id)
        save(spec, ModelState.VERIFYING, file.length(), row?.totalBytes ?: file.length(), row?.installedVersion, false, null)
        val result = withContext(Dispatchers.IO) { ModelFileValidator.validate(spec, file) }
        val state = when (result.status) {
            ModelFileValidator.Status.OK -> ModelState.DOWNLOADED
            ModelFileValidator.Status.BAD_FORMAT -> ModelState.INCOMPATIBLE
            else -> ModelState.ERROR
        }
        val installed = if (state == ModelState.DOWNLOADED) spec.version else row?.installedVersion
        save(
            spec, state, file.length(), file.length(), installed, result.checksumVerified,
            if (state == ModelState.DOWNLOADED) null else result.message
        )
    }

    private suspend fun save(
        spec: ModelSpec,
        state: ModelState,
        downloaded: Long,
        total: Long,
        installed: String?,
        verified: Boolean,
        error: String?
    ) {
        dao.upsert(
            ModelEntity(
                id = spec.id,
                state = state.name,
                downloadedBytes = downloaded,
                totalBytes = total,
                installedVersion = installed,
                checksumVerified = verified,
                errorMessage = error,
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    private fun toItem(spec: ModelSpec, row: ModelEntity?): ModelItem {
        val state = when {
            !spec.configured -> ModelState.NOT_CONFIGURED
            row == null -> ModelState.NOT_DOWNLOADED
            else -> runCatching { ModelState.valueOf(row.state) }.getOrDefault(ModelState.ERROR)
        }
        return ModelItem(
            spec = spec,
            state = state,
            downloadedBytes = row?.downloadedBytes ?: 0L,
            totalBytes = row?.totalBytes?.takeIf { it > 0 } ?: (spec.sizeBytes ?: 0L),
            checksumVerified = row?.checksumVerified ?: false,
            installedVersion = row?.installedVersion,
            errorMessage = row?.errorMessage
        )
    }
}
