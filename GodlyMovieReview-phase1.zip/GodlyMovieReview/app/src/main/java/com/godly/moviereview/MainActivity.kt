package com.godly.moviereview

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.godly.moviereview.navigation.AppNav
import com.godly.moviereview.ui.theme.GodlyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GodlyTheme {
                AppNav()
            }
        }
    }
}
