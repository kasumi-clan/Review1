package com.godly.moviereview.model

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Tải tệp model bằng HTTP, có tiếp tục tải (Range) nếu máy chủ hỗ trợ. */
class ModelDownloader(private val modelsDir: File) {

    class DownloadException(message: String) : IOException(message)

    data class Progress(val downloaded: Long, val total: Long)

    fun targetFile(fileName: String) = File(modelsDir, fileName)
    fun partFile(fileName: String) = File(modelsDir, "$fileName.part")

    suspend fun download(
        url: String,
        fileName: String,
        onProgress: suspend (Progress) -> Unit
    ): File = withContext(Dispatchers.IO) {
        modelsDir.mkdirs()
        val target = targetFile(fileName)
        val part = partFile(fileName)
        var existing = if (part.exists()) part.length() else 0L

        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 30_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "GodlyMovieReview/0.1")
            if (existing > 0) setRequestProperty("Range", "bytes=$existing-")
        }
        try {
            val append: Boolean
            val total: Long
            when (val code = conn.responseCode) {
                HttpURLConnection.HTTP_OK -> {
                    // Tải mới, hoặc máy chủ bỏ qua Range -> bắt đầu lại từ đầu.
                    append = false
                    existing = 0L
                    total = conn.contentLengthLong
                }
                HttpURLConnection.HTTP_PARTIAL -> {
                    append = true
                    val headerTotal = conn.getHeaderField("Content-Range")
                        ?.substringAfterLast('/')
                        ?.toLongOrNull()
                    val len = conn.contentLengthLong
                    total = headerTotal ?: if (len >= 0) existing + len else -1L
                }
                416 -> {
                    part.delete()
                    throw DownloadException("Tệp tải dở không hợp lệ và đã được xóa. Hãy bấm tải lại.")
                }
                else -> throw DownloadException("Máy chủ trả về HTTP $code")
            }

            if (total > 0) {
                val needed = total - existing
                if (modelsDir.usableSpace < needed + MIN_FREE_MARGIN) {
                    throw DownloadException("Không đủ dung lượng trống để tải model")
                }
            }

            conn.inputStream.use { input ->
                FileOutputStream(part, append).use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = existing
                    var lastReport = 0L
                    while (true) {
                        ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.nanoTime()
                        if (now - lastReport > 500_000_000L) {
                            onProgress(Progress(done, total))
                            lastReport = now
                        }
                    }
                    out.fd.sync()
                    onProgress(Progress(done, total))
                    if (total > 0 && done != total) {
                        throw DownloadException("Tải chưa đủ: $done/$total byte")
                    }
                }
            }

            if (target.exists()) target.delete()
            if (!part.renameTo(target)) throw DownloadException("Không đổi tên được tệp sau khi tải xong")
            target
        } finally {
            conn.disconnect()
        }
    }

    private companion object {
        const val MIN_FREE_MARGIN = 50L * 1024 * 1024
    }
}
