package com.godly.moviereview.ui.settings

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.moviereview.BuildConfig
import com.godly.moviereview.storage.DeviceInfo
import com.godly.moviereview.storage.NetworkStatus
import com.godly.moviereview.ui.components.GhostButton
import com.godly.moviereview.ui.components.GlowCard
import com.godly.moviereview.ui.components.InfoRow
import com.godly.moviereview.ui.components.PrimaryButton
import com.godly.moviereview.ui.components.ScreenHeader
import com.godly.moviereview.ui.theme.GodlyBg
import com.godly.moviereview.ui.theme.GodlyOk
import com.godly.moviereview.ui.theme.GodlyText
import com.godly.moviereview.ui.theme.GodlyTextDim
import com.godly.moviereview.util.formatBytes
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun clearCache(context: Context): Long {
    var freed = 0L
    context.cacheDir.listFiles()?.forEach { f ->
        freed += f.walkBottomUp().filter { it.isFile }.sumOf { it.length() }
        f.deleteRecursively()
    }
    return freed
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenModels: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val device = remember { DeviceInfo.snapshot(context) }
    var cacheMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GodlyBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenHeader("Cài đặt", onBack)

        GlowCard {
            Text("Model", color = GodlyText, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            GhostButton("Quản lý model", Modifier.fillMaxWidth(), onClick = onOpenModels)
        }

        GlowCard {
            Text("Thiết bị", color = GodlyText, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            InfoRow("Máy", device.model)
            InfoRow("Android", "${device.androidRelease} (API ${device.sdk})")
            InfoRow("Kiến trúc CPU", device.abis.firstOrNull() ?: "Không xác định")
            InfoRow("RAM tổng", formatBytes(device.totalRamBytes))
            InfoRow("RAM khả dụng lúc mở", formatBytes(device.availRamBytes))
            InfoRow("Bộ nhớ trống", formatBytes(device.freeStorageBytes))
            InfoRow("Mạng", if (NetworkStatus.isOnline(context)) "Có Internet" else "Không có Internet")
        }

        GlowCard {
            Text("Bộ nhớ đệm", color = GodlyText, fontSize = 18.sp)
            Text(
                "Xóa cache không xóa model đã tải và không xóa video gốc.",
                color = GodlyTextDim, fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))
            PrimaryButton("Xóa cache", Modifier.fillMaxWidth()) {
                scope.launch {
                    val freed = withContext(Dispatchers.IO) { clearCache(context) }
                    cacheMessage = "Đã giải phóng ${formatBytes(freed)}"
                }
            }
            cacheMessage?.let {
                Spacer(Modifier.height(6.dp))
                Text(it, color = GodlyOk, fontSize = 13.sp)
            }
        }

        GlowCard {
            Text("Thông tin ứng dụng", color = GodlyText, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            InfoRow("Tên", "GODLY AI MOVIE REVIEW")
            InfoRow("Package", "com.godly.moviereview")
            InfoRow("Phiên bản", BuildConfig.VERSION_NAME)
            Text(
                "Giai đoạn 1: khung ứng dụng, nhập video, quản lý model. Pipeline AI chưa triển khai.",
                color = GodlyTextDim, fontSize = 13.sp
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}
