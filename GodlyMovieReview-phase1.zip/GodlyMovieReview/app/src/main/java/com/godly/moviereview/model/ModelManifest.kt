package com.godly.moviereview.model

import org.json.JSONObject

enum class ModelRole { LLM, STT, TTS, TRANSLATION }

enum class ModelState(val label: String) {
    NOT_DOWNLOADED("Chưa tải"),
    DOWNLOADING("Đang tải"),
    DOWNLOADED("Đã tải"),
    VERIFYING("Đang kiểm tra"),
    ERROR("Bị lỗi"),
    INCOMPATIBLE("Không tương thích"),
    NOT_CONFIGURED("Chưa cấu hình nguồn")
}

data class ModelSpec(
    val id: String,
    val name: String,
    val role: ModelRole,
    val version: String,
    val fileName: String?,
    val url: String?,
    val approxSizeMb: Int?,
    val sizeBytes: Long?,
    val sha256: String?,
    val license: String,
    val sourceName: String,
    val sourceNote: String?,
    val fileMagic: String?
) {
    /** Chỉ model có URL và tên tệp thật mới được tải. */
    val configured: Boolean get() = url != null && fileName != null
}

object ModelManifestParser {
    fun parse(json: String): List<ModelSpec> {
        val arr = JSONObject(json).getJSONArray("models")
        return List(arr.length()) { i ->
            val o = arr.getJSONObject(i)
            ModelSpec(
                id = o.getString("id"),
                name = o.getString("name"),
                role = ModelRole.valueOf(o.getString("role")),
                version = o.getString("version"),
                fileName = o.stringOrNull("fileName"),
                url = o.stringOrNull("url"),
                approxSizeMb = if (o.has("approxSizeMb") && !o.isNull("approxSizeMb")) o.getInt("approxSizeMb") else null,
                sizeBytes = if (o.has("sizeBytes") && !o.isNull("sizeBytes")) o.getLong("sizeBytes") else null,
                sha256 = o.stringOrNull("sha256")?.lowercase(),
                license = o.getString("license"),
                sourceName = o.getString("sourceName"),
                sourceNote = o.stringOrNull("sourceNote"),
                fileMagic = o.stringOrNull("fileMagic")
            )
        }
    }

    private fun JSONObject.stringOrNull(key: String): String? =
        if (has(key) && !isNull(key)) getString(key).takeIf { it.isNotBlank() } else null
}
