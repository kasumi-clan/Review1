package com.godly.moviereview.ui.models

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.godly.moviereview.container
import com.godly.moviereview.model.ModelItem
import com.godly.moviereview.model.ModelState
import com.godly.moviereview.ui.components.GhostButton
import com.godly.moviereview.ui.components.GlowCard
import com.godly.moviereview.ui.components.InfoRow
import com.godly.moviereview.ui.components.PrimaryButton
import com.godly.moviereview.ui.components.ScreenHeader
import com.godly.moviereview.ui.components.StatusChip
import com.godly.moviereview.ui.home.modelStateColor
import com.godly.moviereview.ui.theme.GodlyBg
import com.godly.moviereview.ui.theme.GodlyBlue
import com.godly.moviereview.ui.theme.GodlyDanger
import com.godly.moviereview.ui.theme.GodlyText
import com.godly.moviereview.ui.theme.GodlyTextDim
import com.godly.moviereview.ui.theme.GodlyWarn
import com.godly.moviereview.util.formatBytes
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class ModelManagerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = container().models

    val items: StateFlow<List<ModelItem>> = repo.observe()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun download(id: String) = repo.startDownload(id)
    fun cancel(id: String) = repo.cancelDownload(id)
    fun verify(id: String) = repo.verify(id)
    fun update(id: String) = repo.update(id)
    fun delete(id: String) = repo.delete(id)
}

@Composable
fun ModelManagerScreen(onBack: () -> Unit, vm: ModelManagerViewModel = viewModel()) {
    val items by vm.items.collectAsStateWithLifecycle()
    var downloadTarget by remember { mutableStateOf<ModelItem?>(null) }
    var deleteTarget by remember { mutableStateOf<ModelItem?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(GodlyBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { ScreenHeader("Quản lý model", onBack) }
        item {
            Text(
                "Model chỉ được tải khi bạn bấm Tải. Sau khi tải xong, chính các model này sẽ chạy trên máy. " +
                    "Giai đoạn 1 mới tải và kiểm tra tệp; chưa nạp model vào runtime AI.",
                color = GodlyTextDim, fontSize = 13.sp
            )
        }
        items(items, key = { it.spec.id }) { item ->
            ModelCard(
                item = item,
                onDownload = { downloadTarget = item },
                onCancel = { vm.cancel(item.spec.id) },
                onVerify = { vm.verify(item.spec.id) },
                onUpdate = { vm.update(item.spec.id) },
                onDelete = { deleteTarget = item }
            )
        }
    }

    downloadTarget?.let { m ->
        AlertDialog(
            onDismissRequest = { downloadTarget = null },
            title = { Text("Tải ${m.spec.name}?") },
            text = {
                Text(
                    "Dung lượng: ${sizeText(m)}.\nNguồn: ${m.spec.sourceName}.\n" +
                        "Việc tải dùng dữ liệu mạng của bạn."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.download(m.spec.id); downloadTarget = null }) { Text("Tải") }
            },
            dismissButton = { TextButton(onClick = { downloadTarget = null }) { Text("Hủy") } }
        )
    }

    deleteTarget?.let { m ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Xóa ${m.spec.name}?") },
            text = { Text("Tệp model và phần tải dở sẽ bị xóa khỏi máy.") },
            confirmButton = {
                TextButton(onClick = { vm.delete(m.spec.id); deleteTarget = null }) { Text("Xóa") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Hủy") } }
        )
    }
}

private fun sizeText(m: ModelItem): String = when {
    m.totalBytes > 0 -> formatBytes(m.totalBytes)
    m.spec.approxSizeMb != null -> "~${m.spec.approxSizeMb} MB (ước tính)"
    else -> "Không xác định"
}

@Composable
private fun ModelCard(
    item: ModelItem,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onVerify: () -> Unit,
    onUpdate: () -> Unit,
    onDelete: () -> Unit
) {
    val spec = item.spec
    GlowCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Text(spec.name, color = GodlyText, fontSize = 16.sp, modifier = Modifier.weight(1f))
            StatusChip(item.state.label, modelStateColor(item.state))
        }
        Spacer(Modifier.height(8.dp))
        InfoRow("Phiên bản", spec.version)
        InfoRow("Dung lượng", sizeText(item))
        InfoRow("Giấy phép", spec.license)
        InfoRow("Nguồn", spec.sourceName)

        if (item.state == ModelState.DOWNLOADED) {
            Text(
                if (item.checksumVerified) "SHA-256: đã xác minh"
                else "SHA-256: chưa xác minh (manifest chưa có checksum)",
                color = if (item.checksumVerified) GodlyTextDim else GodlyWarn,
                fontSize = 12.sp
            )
        }
        if (item.state == ModelState.DOWNLOADING || item.state == ModelState.VERIFYING) {
            Spacer(Modifier.height(8.dp))
            if (item.state == ModelState.DOWNLOADING && item.totalBytes > 0) {
                LinearProgressIndicator(
                    progress = { (item.downloadedBytes.toFloat() / item.totalBytes.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth(),
                    color = GodlyBlue
                )
                Text(
                    "${formatBytes(item.downloadedBytes)} / ${formatBytes(item.totalBytes)}",
                    color = GodlyTextDim, fontSize = 12.sp
                )
            } else {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = GodlyBlue)
                if (item.state == ModelState.DOWNLOADING) {
                    Text("Đã tải ${formatBytes(item.downloadedBytes)}", color = GodlyTextDim, fontSize = 12.sp)
                }
            }
        }
        if (item.canResume) {
            Text("Đã có ${formatBytes(item.downloadedBytes)} tải dở, có thể tiếp tục.", color = GodlyTextDim, fontSize = 12.sp)
        }
        item.errorMessage?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = GodlyDanger, fontSize = 12.sp)
        }
        spec.sourceNote?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = GodlyWarn, fontSize = 12.sp)
        }

        val actions: @Composable () -> Unit = {
            when (item.state) {
                ModelState.NOT_CONFIGURED -> Unit
                ModelState.DOWNLOADING -> GhostButton("Dừng", onClick = onCancel)
                ModelState.VERIFYING -> Unit
                ModelState.DOWNLOADED -> {
                    GhostButton("Kiểm tra", onClick = onVerify)
                    if (item.updateAvailable) PrimaryButton("Cập nhật", onClick = onUpdate)
                    GhostButton("Xóa", color = GodlyDanger, onClick = onDelete)
                }
                ModelState.NOT_DOWNLOADED ->
                    PrimaryButton(if (item.canResume) "Tiếp tục tải" else "Tải", onClick = onDownload)
                ModelState.ERROR, ModelState.INCOMPATIBLE -> {
                    PrimaryButton("Tải lại", onClick = onDownload)
                    GhostButton("Xóa", color = GodlyDanger, onClick = onDelete)
                }
            }
        }
        if (item.state != ModelState.NOT_CONFIGURED && item.state != ModelState.VERIFYING) {
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { actions() }
        }
    }
}
