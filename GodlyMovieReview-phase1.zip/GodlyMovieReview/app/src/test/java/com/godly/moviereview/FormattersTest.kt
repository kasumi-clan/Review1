package com.godly.moviereview

import com.godly.moviereview.util.formatBytes
import com.godly.moviereview.util.formatDuration
import org.junit.Assert.assertEquals
import org.junit.Test

class FormattersTest {
    @Test
    fun formatsBytes() {
        assertEquals("512 B", formatBytes(512))
        assertEquals("1.0 KB", formatBytes(1024))
        assertEquals("1.5 MB", formatBytes(1_572_864))
        assertEquals("Không xác định", formatBytes(-1))
    }

    @Test
    fun formatsDuration() {
        assertEquals("0:05", formatDuration(5_000))
        assertEquals("2:03", formatDuration(123_000))
        assertEquals("1:01:01", formatDuration(3_661_000))
    }
}
