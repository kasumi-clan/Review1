package com.godly.moviereview

import com.godly.moviereview.model.ModelDownloader
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import java.io.File
import java.net.InetSocketAddress
import java.nio.file.Files

/** Kiểm thử tải thật qua HTTP cục bộ (máy chủ JDK), gồm cả tiếp tục tải bằng Range. */
class ModelDownloaderTest {
    private lateinit var server: HttpServer
    private lateinit var dir: File
    private val payload = ByteArray(600_000) { (it % 251).toByte() }

    @Volatile
    private var lastRange: String? = null

    @Before
    fun setUp() {
        dir = Files.createTempDirectory("models").toFile()
        server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        server.createContext("/m.bin") { ex ->
            val range = ex.requestHeaders.getFirst("Range")
            lastRange = range
            if (range != null && range.startsWith("bytes=")) {
                val start = range.removePrefix("bytes=").substringBefore('-').toInt()
                val body = payload.copyOfRange(start, payload.size)
                ex.responseHeaders.add("Content-Range", "bytes $start-${payload.size - 1}/${payload.size}")
                ex.sendResponseHeaders(206, body.size.toLong())
                ex.responseBody.use { it.write(body) }
            } else {
                ex.sendResponseHeaders(200, payload.size.toLong())
                ex.responseBody.use { it.write(payload) }
            }
        }
        server.start()
    }

    @After
    fun tearDown() {
        server.stop(0)
        dir.deleteRecursively()
    }

    private fun url() = "http://127.0.0.1:${server.address.port}/m.bin"

    @Test
    fun downloadsFullFile() {
        runBlocking {
            val file = ModelDownloader(dir).download(url(), "m.bin") { }
            assertArrayEquals(payload, file.readBytes())
            assertFalse(File(dir, "m.bin.part").exists())
        }
    }

    @Test
    fun resumesFromPartFile() {
        runBlocking {
            File(dir, "m.bin.part").writeBytes(payload.copyOfRange(0, 100_000))
            val file = ModelDownloader(dir).download(url(), "m.bin") { }
            assertEquals("bytes=100000-", lastRange)
            assertArrayEquals(payload, file.readBytes())
        }
    }
}
