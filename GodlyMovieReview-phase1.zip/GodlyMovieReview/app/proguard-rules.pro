# Giai đoạn 1: minify tắt, chưa cần rule
