# GODLY AI MOVIE REVIEW

Ứng dụng Android tạo video review/recap phim, mục tiêu chạy AI hoàn toàn trên máy (ưu tiên Samsung Galaxy A51, arm64-v8a, Android 13).
Package: `com.godly.moviereview`.

> **Trạng thái: Giai đoạn 1 / 6.** Đây là khung ứng dụng thật, chưa phải sản phẩm hoàn chỉnh.
> Đọc `IMPLEMENTATION_STATUS.md` để biết chính xác cái gì đã làm, đã build, đã kiểm thử và chưa làm.

## Giai đoạn 1 có gì

- Giao diện Compose (dark, xanh dương × trắng, glow nhẹ): Home, Nhập video, Quản lý model, Cài đặt.
- Nhập video bằng trình chọn tệp của hệ thống; đọc thông tin thật (độ phân giải, FPS, thời lượng, dung lượng); xem trước; lưu danh sách gần đây (Room). Không sao chép, không ghi đè video gốc.
- Quản lý model: tải bằng HTTP có tiếp tục tải (Range), kiểm tra dung lượng trống, kiểm tra tệp (định dạng, kích thước, SHA-256 nếu manifest có), cập nhật, xóa; khôi phục trạng thái đúng sau khi app bị đóng giữa chừng.
- GitHub Actions: kiểm tra cấu trúc → unit test → build Debug APK → kiểm tra APK → upload artifact.

## Chưa có (làm ở các giai đoạn sau)

llama.cpp, whisper.cpp (JNI/NDK), phân tích cảnh, viết kịch bản, Vietsub (ML Kit), giọng đọc tiếng Việt, ghép và xuất MP4, màn hình Review Settings / Processing / Script Editor / Subtitle Editor / Export.
Hiện app **chưa tạo được review**, dù online hay offline.

## Build APK

### Cách 1 — GitHub Actions (khuyên dùng)

1. Tạo repository GitHub, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions** → workflow **Build APK** (tự chạy khi push, hoặc bấm *Run workflow*).
3. Khi xong, tải artifact **GodlyMovieReview-debug-apk**.
4. Nếu workflow đỏ: mở bước bị lỗi, chép tên task + dòng lỗi gửi lại để sửa. Không có bước nào bị bỏ qua để "giả xanh".

### Cách 2 — Build trên máy

Cần JDK 17, Android SDK (platform 34, build-tools 34.0.0) và Gradle 8.9.
Dự án chưa kèm Gradle Wrapper (không tạo được khi không có Internet). Tạo bằng: `gradle wrapper --gradle-version 8.9`.

```
gradle :app:testDebugUnitTest
gradle :app:assembleDebug
```

APK nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

## Tải model

Model **không** nằm trong APK. Mở app → Cài đặt → Quản lý model → bấm **Tải** cho từng model.

Danh sách và nguồn nằm ở `model-config/model_manifest.json`. Các URL hiện có là nguồn công khai trên Hugging Face
nhưng **chưa được xác minh trong lúc phát triển** (không có Internet), và `sha256` còn `null`. Khi có Internet chạy:

```
python3 scripts/verify_models.py          # kiểm tra nguồn còn sống, đọc kích thước và SHA-256
python3 scripts/verify_models.py --write  # ghi sizeBytes/sha256 vào manifest
```

Giọng đọc tiếng Việt và tài nguyên dịch (ML Kit) được đánh dấu **chưa cấu hình** — không có URL giả.

## Giấy phép của thành phần bên thứ ba (cần xác minh lại trước khi phát hành)

| Thành phần | Giấy phép ghi nhận | Ghi chú |
|---|---|---|
| AndroidX, Jetpack Compose, Room, Navigation, Lifecycle | Apache-2.0 | |
| Kotlin, kotlinx.coroutines | Apache-2.0 | |
| Qwen2.5-0.5B-Instruct (GGUF) | Apache-2.0 | kiểm tra lại trên trang model |
| Whisper (model ggml) / whisper.cpp | MIT | kiểm tra lại |
| llama.cpp | MIT | chưa tích hợp |
| Google ML Kit Translation | Điều khoản ML Kit | chưa tích hợp |
| Giọng TTS tiếng Việt | Chưa chọn | phải kiểm tra trước khi dùng |

Giấy phép của chính dự án này **chưa được chọn** (chưa có tệp LICENSE).
